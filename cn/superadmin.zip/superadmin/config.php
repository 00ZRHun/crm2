<?php
session_start();
date_default_timezone_set("Asia/Kuala_Lumpur");
//include('auth.php');
$servername = "localhost";
/*$username = "ccrdskmy_loansw";
$password = "gq5QBO,Z8UQN";
$dbname = "ccrdskmy_loan_software";*/
$username = "ecadmin_crm";
$password = "bXwM}E=ME^!t";
$dbname = "ecadmin_crm";

//define("SITEURL","http://readyforyourreview.com/Loan_software"); 
define("SITEURL","http://crm.ecomdemo.xyz");
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 

?>